"""High-level operations used by the MCP server, the hooks, the CLI and Shield Desk (ARCHITECTURE.md 4.4).

Two kinds of callers:

- **Model-facing** (MCP tools, hook outputs): :func:`list_dossiers`, :func:`list_documents`,
  :func:`read_document`, :func:`search`, :func:`save_draft`, :func:`status`, :func:`scan_text`.
  They return codes and masked text only. Every model-facing string also goes through a last canary:
  a registered value of any dossier that is still present is replaced by its code (or by ``[PERSONNE]``)
  before it leaves this module.
- **Local only** (Desk page, CLI in the user's terminal): :func:`mask_text` with ``include_values``,
  :func:`restore_text`, :func:`entities`, ``list_dossiers(include_private=True)``... These may return real
  values because they never reach a model.

Fail closed: every public function catches all errors and raises :class:`ShieldError`, whose message holds
codes only (DOSSIER_n, DOC_n, PERSONNE_A) and short error codes, never a value, a title, a path or document
text. The original error is logged locally with its type and code location only.
"""
from __future__ import annotations

import bisect
import contextlib
import contextvars
import functools
import logging
import os
import re
import sys
import threading
import traceback
import unicodedata
import uuid as uuidlib
from collections import Counter, OrderedDict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Optional

from . import __version__, config, documents
from .engine import (
    CODE_RE,
    KINDS,
    UNMASK_RE,
    Entity,
    Masker,
    MemoryStore,
    Span,
    entity_norm,
    fold,
    has_party_separator,
    normalize,
    parse_parties,
    prefix_for,
)
from .engine import ner as _ner
from .engine.masker import ScanPrep, prepare_scan
from .engine.types import PREFIXES
from .vault import DOSSIER_SETTINGS, UNSUPPORTED_KIND, Dossier, Registry, UnknownDossier, VaultError

log = logging.getLogger(__name__)

__all__ = [
    "ShieldError",
    "Service",
    "default",
    "reset",
    "list_dossiers",
    "list_documents",
    "read_document",
    "search",
    "save_draft",
    "save_draft_report",
    "mask_text",
    "set_dossier_setting",
    "restore_text",
    "restore_report",
    "scan_text",
    "has_registered",
    "status",
    "add_dossier",
    "scan_dossier",
    "remove_dossier",
    "entities",
    "register",
    "keep_clear",
    "journal",
    "mask_file",
    "protect",
    "output_dossier",
    "LIMITS",
]

DOSSIER_RE = re.compile(r"^DOSSIER_([0-9]{1,6})$")
DOC_RE = re.compile(r"^DOC_([0-9]{1,7})$")

DEFAULT_READ_CHARS = 20_000
MIN_READ_CHARS = 500
MAX_READ_CHARS = 50_000
MAX_QUERY_CHARS = 500
DEFAULT_SEARCH_RESULTS = 10
MAX_SEARCH_RESULTS = 50
SNIPPET_RADIUS = 160
MAX_DRAFT_CHARS = 2_000_000
MAX_MASK_CHARS = 5_000_000
#: Biggest document text Shield reads (about 1,200 pages): masking runs at a few µs per character, and an MCP
#: tool must answer within the app's time limit.
MAX_DOCUMENT_CHARS = 3_000_000
MAX_TITLE_CHARS = 200
_CACHE_DOCS = 64

#: Honest limits, shown by ``shield_status`` and the Desk (French, then English).
LIMITS: tuple[tuple[str, str], ...] = (
    ("Pseudonymisation locale et réversible : ce n'est pas une anonymisation.",
     "Local, reversible pseudonymisation: this is not anonymisation."),
    ("La détection n'est jamais complète : relisez le texte masqué dans les cas sensibles.",
     "Detection is never complete: review the masked text for sensitive cases."),
    ("Pas d'OCR en v0.1 : un PDF scanné sans couche texte n'est pas lu.",
     "No OCR in v0.1: a scanned PDF without a text layer is not read."),
    ("Un texte collé ou un fichier joint dans la conversation part chez le fournisseur avant Shield.",
     "Text pasted or files attached in the chat reach the provider before Shield can act."),
    ("Un nom seul dans un tableau, sans civilité ni prénom connu, peut être manqué.",
     "A bare name in a table cell, with no title and no known first name, can be missed."),
    ("Les numéros de décisions publiées (pourvoi, ECLI) sont masqués comme ceux du client.",
     "Published case numbers (pourvoi, ECLI) are masked like the client's own."),
)

_CODE_SHAPE = re.compile(r"[A-Z]{2,12}_(?:[A-Z]{1,4}|[0-9]{1,6})")
_SENTINEL_RE = re.compile("[0-9]+")
_WORD_CHARS = re.compile(r"[a-z0-9]")
#: Generic marks the canary writes when it cannot give a code ("[PERSONNE]", "[COMPANY]"...): they cannot be
#: restored, so a saved draft that still holds one is reported (R1 correction CL-31).
_PLACEHOLDER_RE = re.compile(r"\[(?:" + "|".join(sorted({p for fr, en, _l in PREFIXES.values() for p in (fr, en)},
                                                         key=len, reverse=True)) + r")\]")
#: Shield object ids (not entity codes): restore never gives them a value (CL-36).
_SHIELD_ID_RE = re.compile(r"(?<![A-Za-z0-9_])(?:DOSSIER_[0-9]{1,6}|DOC_[0-9]{1,7}|OUTPUT_[0-9]{1,7})(?![A-Za-z0-9_])")
#: Dossier of the model-facing string being guarded (set by the MCP server around its last canary, CL-26).
_OUTPUT_DOSSIER: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar("ragbase_shield_output_dossier",
                                                                               default=None)


class ShieldError(Exception):
    """A Shield operation failed. The message holds codes only (never a value, a title or a path).

    ``kind`` is a short machine code: ``invalid_argument``, ``unknown_dossier``, ``unknown_document``,
    ``document_unreadable``, ``vault_error``, ``write_failed``, ``internal``...
    """

    def __init__(self, message: str, kind: str = "error"):
        super().__init__(message)
        self.kind = kind


# ------------------------------------------------------------------------------------------ helpers

def _log_failure(op: str, exc: BaseException) -> str:
    """Log a failure locally with its type and code location only (no message: it may hold a value)."""
    ref = uuidlib.uuid4().hex[:8]
    frames = traceback.extract_tb(exc.__traceback__)[-4:]
    where = " < ".join(f"{Path(f.filename).name}:{f.lineno}:{f.name}" for f in reversed(frames))
    log.warning("RAGbase Shield: %s failed (ref %s): %s at %s", op, ref, type(exc).__name__, where or "?")
    return ref


def _guarded(op: str) -> Callable:
    """Decorator: every error leaves as a ShieldError with a code-only message (fail closed)."""

    def deco(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                return fn(*args, **kwargs)
            except ShieldError:
                raise
            except UnknownDossier:
                raise ShieldError("Dossier inconnu (unknown dossier). Appelez shield_list_dossiers.",
                                  "unknown_dossier") from None
            except VaultError:
                ref = _log_failure(op, _current_exc())
                raise ShieldError(f"Coffre RAGbase Shield illisible ou clé absente (vault error, ref {ref}). "
                                  "Lancez « ragbase-shield doctor ».", "vault_error") from None
            except documents.DocumentError as exc:
                code = str(exc) if re.fullmatch(r"[a-z_]{3,40}(?::[0-9]{1,6})?", str(exc)) else "unreadable"
                raise ShieldError(f"Document illisible ({code}).", "document_unreadable") from None
            except Exception:  # noqa: BLE001 - fail closed, never echo the message
                ref = _log_failure(op, _current_exc())
                raise ShieldError(f"Erreur interne de RAGbase Shield (internal error, ref {ref}).",
                                  "internal") from None

        return wrapper

    return deco


def _current_exc() -> BaseException:
    import sys

    exc = sys.exc_info()[1]
    assert exc is not None
    return exc


def _dossier_code(value: Any) -> str:
    s = str(value if value is not None else "").strip().upper()
    if not DOSSIER_RE.match(s):
        raise ShieldError("Code de dossier invalide : attendu DOSSIER_n (invalid dossier code).",
                          "invalid_argument")
    return s


def _doc_code(value: Any) -> str:
    s = str(value if value is not None else "").strip().upper()
    if not DOC_RE.match(s):
        raise ShieldError("Code de document invalide : attendu DOC_n (invalid document code).",
                          "invalid_argument")
    return s


def _kind_arg(value: Any) -> str:
    s = str(value or "").strip().upper()
    if s not in KINDS:
        raise ShieldError("Type inconnu (unknown kind). Types : " + ", ".join(KINDS), "invalid_argument")
    return s


def _replacement_arg(value: Any) -> Optional[str]:
    """"codes" | "synthetic" | None (default), or ShieldError for anything else (v0.2)."""
    if value is None or value == "":
        return None
    v = str(value).strip().lower()
    if v not in ("codes", "synthetic"):
        raise ShieldError("Mode de remplacement inconnu : codes ou synthetic (unknown replacement mode).",
                          "invalid_argument")
    return v


def _nfc(text: str) -> str:
    """NFC form: decomposed accents (macOS file names, some PDF text) would cut names in two."""
    return unicodedata.normalize("NFC", text) if text and not text.isascii() else text


def _escape_outside(text: str, spans: list[Span]) -> str:
    """The original text with code-like strings escaped the way the masker does (same length)."""
    from .engine.masker import code_like_spans

    starts = [s.start for s in spans]
    out = list(text)
    for a, b, _code in code_like_spans(text):
        i = bisect.bisect_right(starts, b - 1) - 1
        if i >= 0 and spans[i].end > a:
            continue  # inside a replaced span
        for k in range(a, b):
            if out[k] == "_":
                out[k] = "-"
                break
    return "".join(out)


@dataclass
class _Alignment:
    """Offsets of the replaced spans in the original text and in the masked text."""

    starts: list[int] = field(default_factory=list)
    ends: list[int] = field(default_factory=list)
    mstarts: list[int] = field(default_factory=list)
    mends: list[int] = field(default_factory=list)
    codes: list[str] = field(default_factory=list)

    def to_masked(self, pos: int) -> int:
        i = bisect.bisect_right(self.starts, pos) - 1
        if i < 0:
            return pos
        if pos < self.ends[i]:
            return self.mstarts[i]
        return pos - self.ends[i] + self.mends[i]

    def overlaps(self, s: int, e: int) -> bool:
        i = bisect.bisect_right(self.starts, e - 1) - 1
        return i >= 0 and self.ends[i] > s


@dataclass
class _Chain:
    """Alignments applied one after the other: the masker spans, then each pass of the last canary (R1 CL-25).

    Maps an offset of the original text to the text the model sees, and tells whether a slice of the original
    text was replaced by any step."""

    steps: list[_Alignment] = field(default_factory=list)

    def to_masked(self, pos: int) -> int:
        for st in self.steps:
            pos = st.to_masked(pos)
        return pos

    def overlaps(self, s: int, e: int) -> bool:
        for st in self.steps:
            if st.overlaps(s, e):
                return True
            s, e = st.to_masked(s), st.to_masked(e)
        return False


def _edits_alignment(edits: list[tuple[int, int, str]]) -> _Alignment:
    """Alignment of one canary pass from its edits (start, end, replacement), sorted and without overlaps."""
    al = _Alignment()
    delta = 0
    for s, e, rep in edits:
        al.starts.append(s)
        al.ends.append(e)
        al.mstarts.append(s + delta)
        al.mends.append(s + delta + len(rep))
        al.codes.append(rep)
        delta += len(rep) - (e - s)
    return al


def _glued_code(text: str, s: int, e: int, code: str) -> str:
    """The code that replaces ``text[s:e]``, with a space where a glued letter or digit would hide it from
    restore ("2026Brakel" -> "2026 PERSONNE_C")."""
    before = " " if s > 0 and text[s - 1].isalnum() else ""
    nxt = text[e] if e < len(text) else ""
    letters = code.rsplit("_", 1)[-1].isalpha()
    after = " " if nxt and ((letters and nxt.isupper()) or (not letters and nxt.isdigit())) else ""
    return before + code + after


def _align(original: str, masked: str, spans: list[Span], codes: set[str]) -> Optional[_Alignment]:
    """Find where each replaced span sits in the masked text. None if the texts do not line up."""
    spans = sorted(spans, key=lambda s: s.start)
    escaped = _escape_outside(original, spans)
    al = _Alignment()
    delta = 0
    for i, sp in enumerate(spans):
        ms = sp.start + delta
        nxt = spans[i + 1].start if i + 1 < len(spans) else len(original)
        seg = escaped[sp.end:nxt]
        # The masker adds a space next to a code glued to a letter or a digit ("2026 PERSONNE_A").
        lead = 1 if ms < len(masked) and masked[ms] == " " and sp.start > 0 and original[sp.start - 1].isalnum() \
            else 0
        ms += lead
        if ms < len(masked) and masked[ms] == "":
            m = _SENTINEL_RE.match(masked, ms)
            length = len(m.group()) if m and masked.startswith(seg, m.end()) else None
        else:
            m = _CODE_SHAPE.match(masked, ms)
            length = None
            if m:
                cand = m.group()
                for n in range(len(cand), 2, -1):
                    if cand[:n] in codes and masked.startswith(seg, ms + n):
                        if seg or i + 1 == len(spans) or _CODE_SHAPE.match(masked, ms + n) \
                                or masked.startswith("", ms + n):
                            length = n
                            break
        trail = 0
        if length is None and m is not None and masked[ms:ms + 1] != "":
            cand = _CODE_SHAPE.match(masked, ms)
            for n in range(len(cand.group()) if cand else 0, 2, -1):
                if cand.group()[:n] in codes and masked[ms + n:ms + n + 1] == " " and masked.startswith(seg, ms + n + 1):
                    length, trail = n, 1
                    break
        if length is None:
            return None
        al.starts.append(sp.start)
        al.ends.append(sp.end)
        al.mstarts.append(ms)
        al.mends.append(ms + length)
        al.codes.append(masked[ms:ms + length])
        delta += lead + length + trail - (sp.end - sp.start)
    if len(original) + delta != len(masked):
        return None
    return al


def _cut(text: str, start: int, max_chars: int) -> int:
    """End offset of a page: at most ``max_chars`` after ``start``, at a line or word break, never inside a code."""
    end = min(len(text), start + max_chars)
    if end >= len(text):
        return len(text)
    floor = start + int(max_chars * 0.8)
    nl = text.rfind("\n", floor, end)
    if nl > start:
        end = nl + 1
    else:
        sp = text.rfind(" ", floor, end)
        if sp > start:
            end = sp + 1
    for m in UNMASK_RE.finditer(text, max(start, end - 20), min(len(text), end + 20)):
        if m.start() < end < m.end():
            end = m.start() if m.start() > start else m.end()
    return end


def _snap_left(text: str, pos: int, limit: int) -> int:
    """Move ``pos`` left to a word start (at most ``limit`` chars), never inside a code."""
    lo = max(0, pos - limit)
    sp = max(text.rfind(" ", lo, pos), text.rfind("\n", lo, pos))
    pos = sp + 1 if sp >= 0 else pos
    for m in UNMASK_RE.finditer(text, max(0, pos - 20), min(len(text), pos + 20)):
        if m.start() < pos < m.end():
            pos = m.start()
    return pos


def _snap_right(text: str, pos: int, limit: int) -> int:
    hi = min(len(text), pos + limit)
    cands = [i for i in (text.find(" ", pos, hi), text.find("\n", pos, hi)) if i >= 0]
    pos = min(cands) if cands else pos
    for m in UNMASK_RE.finditer(text, max(0, pos - 20), min(len(text), pos + 20)):
        if m.start() < pos < m.end():
            pos = m.end()
    return pos


class _DryStore:
    """EntityStore wrapper that never writes: new entities get a private sentinel code.

    Used to find which registered entities a text contains without polluting the dossier.
    ``protect`` codes are reported as known, so masking with ``keep_known_codes=True`` keeps them.
    """

    def __init__(self, real: Any, protect: Iterable[str] = ()):
        self.real = real
        self.locale = getattr(real, "locale", "fr")
        self._protect = set(protect)
        self._by_norm: dict[tuple[str, str], Entity] = {}
        self._by_code: dict[str, Entity] = {}

    def all(self) -> list[Entity]:
        return self.real.all()

    def get_by_norm(self, kind: str, norm: str) -> Optional[Entity]:
        return self._by_norm.get((kind, norm)) or self.real.get_by_norm(kind, norm)

    def get_by_code(self, code: str) -> Optional[Entity]:
        ent = self.real.get_by_code(code) or self._by_code.get(code)
        if ent is None and code in self._protect:
            return Entity(kind="PERSON", value=code, norm=code.lower(), code=code)
        return ent

    def add(self, kind: str, value: str, norm: str) -> Entity:
        key = (kind, norm)
        if key in self._by_norm:
            return self._by_norm[key]
        ent = Entity(kind=kind, value=value, norm=norm, code=f"{len(self._by_code) + 1}")
        self._by_norm[key] = ent
        self._by_code[ent.code] = ent
        return ent

    def is_kept_clear(self, norm: str) -> bool:
        return self.real.is_kept_clear(norm)


@dataclass
class _CachedDoc:
    mtime_ns: int
    size: int
    version: tuple[int, int]
    raw: str
    masked: str            # masked text after the last canary of every dossier: what the model reads
    alignment: Any         # _Chain from ``raw`` to ``masked`` (None when the texts do not line up)
    needs_ocr: bool
    pages: Optional[int]
    warnings: tuple[str, ...]
    masked0: str = ""      # masker output before the canary
    align0: Optional[_Alignment] = None
    epoch: tuple = ()      # dossier revisions the canary saw (a change of any dossier guards again)
    _folded_raw: Any = None
    _folded_masked: Any = None

    @property
    def folded_raw(self):
        if self._folded_raw is None:
            self._folded_raw = fold(self.raw)
        return self._folded_raw

    @property
    def folded_masked(self):
        if self._folded_masked is None:
            self._folded_masked = fold(self.masked)
        return self._folded_masked


# ------------------------------------------------------------------------------------------ service

class Service:
    """Shield operations over one data directory (``config.home()`` by default)."""

    def __init__(self, home: Optional[os.PathLike | str] = None):
        self._home = Path(home) if home is not None else None
        self._lock = threading.RLock()
        self._registry: Optional[Registry] = None
        self._maskers: dict[str, tuple[str, Masker]] = {}
        self._rule_maskers: dict[str, tuple[str, Masker]] = {}
        self._indexes: dict[str, tuple[Any, dict]] = {}
        self._label_indexes: dict[str, tuple[Any, dict]] = {}
        self._docs: OrderedDict[tuple[str, str], _CachedDoc] = OrderedDict()
        self._pages: dict[tuple[str, int, int], Optional[int]] = {}

    # ---------------------------------------------------------------- plumbing
    @property
    def registry(self) -> Registry:
        with self._lock:
            if self._registry is None:
                self._registry = Registry(self._home)
            return self._registry

    def close(self) -> None:
        with self._lock:
            if self._registry is not None:
                self._registry.close()
            self._registry = None
            self._maskers.clear()
            self._rule_maskers.clear()
            self._indexes.clear()
            self._label_indexes.clear()
            self._docs.clear()

    def _dossier(self, code: Any) -> Dossier:
        return self.registry.get(_dossier_code(code))

    def _masker(self, d: Dossier, replacement: Optional[str] = None) -> Masker:
        """The dossier masker used for documents and pasted text (optional NER when installed).

        ``replacement`` (v0.2): "codes" or "synthetic"; by default the dossier setting, else
        ``config.replacement()``. One masker is cached per (dossier, replacement)."""
        replacement = _replacement_arg(replacement) or self._dossier_replacement(d)
        key = f"{d.code}:{replacement}"
        cached = self._maskers.get(key)
        if cached is not None and cached[0] == d.uuid:
            return cached[1]
        # v0.2: the dossier language setting (else RAGBASE_SHIELD_LANGUAGE) and the NER model setting;
        # v0.4 (P1): the own-company vendor option (RAGBASE_SHIELD_OWN_COMPANY_VENDOR, default off)
        m = Masker(d, locale=d.locale, replacement=replacement, language=self._dossier_language(d),
                   ner_model=config.ner_model(), own_company_vendor=config.own_company_vendor())
        self._maskers[key] = (d.uuid, m)
        return m

    def _drop_maskers(self, code: str) -> None:
        """Forget the cached maskers of a dossier (every replacement mode)."""
        for key in [k for k in self._maskers if k == code or k.startswith(code + ":")]:
            del self._maskers[key]

    @staticmethod
    def _dossier_language(d: Dossier) -> str:
        setting = getattr(d, "setting", None)
        try:
            value = setting("language") if callable(setting) else None
        except Exception:  # noqa: BLE001 - an old store: the global default
            value = None
        return value or config.language()

    @staticmethod
    def _dossier_replacement(d: Dossier) -> str:
        setting = getattr(d, "setting", None)
        try:
            value = setting("replacement") if callable(setting) else None
        except Exception:  # noqa: BLE001 - an old store: the global default
            value = None
        return value or config.replacement()

    def _rules(self, d: Dossier) -> Masker:
        """Rules-only masker of the dossier: canary, hooks, labels (never loads a NER model)."""
        cached = self._rule_maskers.get(d.code)
        if cached is not None and cached[0] == d.uuid:
            return cached[1]
        m = Masker(d, locale=d.locale, use_ner=False, own_company_vendor=config.own_company_vendor())
        self._rule_maskers[d.code] = (d.uuid, m)
        return m

    def _open_dossiers(self) -> list[Dossier]:
        """Every registered dossier, for a model-facing check. Fail closed: if ONE vault cannot be opened, its
        values could no longer be checked, so the whole check fails (ShieldError ``vault_error``)."""
        out = []
        for code in self.registry.folders():
            try:
                out.append(self.registry.get(code))
            except VaultError:
                log.warning("RAGbase Shield: %s cannot be opened; the check fails closed", code)
                raise ShieldError(f"Le coffre de {code} ne s'ouvre pas : vérification impossible, rien n'est "
                                  "renvoyé. Lancez « ragbase-shield doctor » ou retirez ce dossier dans Shield Desk. "
                                  f"(vault of {code} unreadable: failing closed)", "vault_error") from None
        return out

    @staticmethod
    def _version(d: Dossier) -> Any:
        return d.revision

    def _invalidate(self, code: str) -> None:
        for key in [k for k in self._docs if k[0] == code]:
            del self._docs[key]

    # ---------------------------------------------------------------- canary
    def _index(self, d: Dossier) -> dict:
        """Lookup tables of the dossier's entities by engine key and by surname (cached per dossier version)."""
        ents = d.all()
        rev = d.revision
        cached = self._indexes.get(d.code)
        if cached is not None and cached[0] == rev:
            return cached[1]
        from .engine.names import first_key, surname_key

        by_key: dict[tuple[str, str], set[str]] = {}
        by_surname: dict[str, set[str]] = {}
        by_first: dict[str, set[str]] = {}
        by_variant: dict[tuple[str, tuple[str, ...]], set[str]] = {}
        for e in ents:
            for key in {e.norm, _safe_norm(e.kind, e.value)}:
                if key:
                    by_key.setdefault((e.kind, key), set()).add(e.code)
            if e.kind == "PERSON":
                sk = surname_key(e.value)
                if sk:
                    by_surname.setdefault(sk, set()).add(e.code)
                for tok in first_key(e.value).split():
                    by_first.setdefault(tok, set()).add(e.code)
            if e.kind in ("PERSON", "ORG"):
                for toks in _variant_keys(e.kind, e.value):
                    by_variant.setdefault((e.kind, toks), set()).add(e.code)
        index = {"key": by_key, "surname": by_surname, "first": by_first, "variant": by_variant}
        self._indexes[d.code] = (rev, index)
        return index

    def _entity_for(self, d: Dossier, kind: str, surface: str) -> Optional[Entity]:
        """Best-effort entity behind a surface form found by the canary (same engine key, or a unique surname).

        A one-word surface that is the surname of one person and the first name of another one is ambiguous:
        None, never the wrong person (R1, with CL-20 and CL-26)."""
        index = self._index(d)
        codes = index["key"].get((kind, _safe_norm(kind, surface)), set())
        if len(codes) != 1 and kind == "PERSON":
            from .engine.names import surname_key

            sk = surname_key(surface)
            codes = set(index["surname"].get(sk, set())) if sk else set()
            if codes and sk and " " not in sk:
                codes |= index["first"].get(sk, set())
        if not codes and kind in ("PERSON", "ORG"):
            # a short form the engine knows (acronym, initials, nickname, head word): its owners, if only one
            from .engine.normalize import phrase_tokens

            codes = index["variant"].get((kind, phrase_tokens(surface, confusables=True)), set())
        if len(codes) == 1:
            return d.get_by_code(next(iter(codes)))
        return None

    def _kept(self, d: Dossier, span: Span) -> bool:
        for key in (normalize(span.value), _safe_norm(span.kind, span.value)):
            if key and d.is_kept_clear(key):
                return True
        ent = self._entity_for(d, span.kind, span.value)
        return bool(ent is not None and d.is_kept_clear(ent.norm))

    def _leftovers(self, d: Dossier, text: str, prep: Optional[ScanPrep] = None) -> list[Span]:
        """Registered values of ``d`` still present in ``text`` (lenient canary, kept-clear terms ignored)."""
        if not text or not d.all():
            return []
        spans = []
        for sp in self._rules(d).scan(text, prepared=prep):
            # known values come back as "dictionary"; a registered identifier that is also a valid structured
            # id (e-mail, IBAN...) comes back as "regex": keep it only when it is one of the dossier's values
            if sp.source == "dictionary" or (sp.source == "regex" and self._entity_for(d, sp.kind, sp.value)):
                spans.append(sp)
        return [sp for sp in spans if not self._kept(d, sp)]

    def _redact(self, text: str, hits: list[Span], d: Dossier, own: bool,
                mint_into: Optional[Dossier] = None) -> tuple[str, list[tuple[int, int, str]]]:
        """Replace canary hits of dossier ``d``. Returns (text, edits), edits = (start, end, replacement) in the
        input offsets, sorted.

        A hit of the dossier's own entity gets its code (``own``). Otherwise, with ``mint_into`` (the dossier
        the text belongs to), the value becomes a NEW entity of that dossier, so the code can be restored there
        (R1 correction CL-26); without it, a generic placeholder ("[PERSONNE]") that nothing restores."""
        edits: list[tuple[int, int, str]] = []
        last = len(text) + 1
        for s in sorted(hits, key=lambda s: s.start, reverse=True):
            if s.end > last:
                continue
            ent = self._entity_for(d, s.kind, s.value) if own else None
            if ent is None and mint_into is not None:
                # the same name may already be an entity of the text's own dossier: reuse its code
                ent = (None if own else self._entity_for(mint_into, s.kind, s.value)) \
                    or self._mint(mint_into, s.kind, text[s.start:s.end])
            rep = _glued_code(text, s.start, s.end, ent.code) if ent is not None \
                else f"[{prefix_for(s.kind, d.locale)}]"
            edits.append((s.start, s.end, rep))
            last = s.start
        edits.reverse()
        parts: list[str] = []
        pos = 0
        for s, e, rep in edits:
            parts.append(text[pos:s])
            parts.append(rep)
            pos = e
        parts.append(text[pos:])
        return "".join(parts), edits

    def _mint(self, d: Dossier, kind: str, surface: str) -> Optional[Entity]:
        """The entity of ``d`` for a value the canary found (created when new). None if it cannot be made, or
        when the user keeps this term in clear in ``d``: the caller then writes a placeholder."""
        value = " ".join(surface.split())
        norm = _safe_norm(kind, value)
        if not value or not norm or d.is_kept_clear(norm) or d.is_kept_clear(normalize(value)):
            return None
        try:
            return d.add(kind, value, norm)
        except Exception:  # noqa: BLE001 - code range exhausted, refused value: keep the placeholder
            log.warning("RAGbase Shield: %s: a canary value could not get a code; placeholder kept", d.code)
            return None

    def _foreign_hit(self, d: Dossier, text: str, sp: Span) -> bool:
        """A canary hit of dossier ``d`` in a text that belongs to ANOTHER dossier: True when it must still be
        replaced (R1 correction CL-26).

        A whole registered value, or a name of several words, always is. A single word that is only PART of a
        registered name of ``d`` is replaced only when it is a strong name word (in no word list) written with a
        capital, or a social handle: a common word, a first name or a lower-case word of the other dossier stays
        as it is in this dossier's text ("la dette financière nette")."""
        if sp.kind not in ("PERSON", "ORG"):
            return True
        word = sp.value.strip()
        if not word or any(c.isspace() for c in word):
            return True
        if self._index(d)["key"].get((sp.kind, _safe_norm(sp.kind, word))):
            return True  # the whole registered value
        if sp.start > 0 and text[sp.start - 1] == "@":
            return True
        if not word[0].isupper():
            return False
        from .engine.normalize import fold_word

        return _strong_name_word(fold_word(word))

    def _guard(self, text: str, primary: Optional[Dossier] = None) -> str:
        """Last canary on a model-facing string: no registered value of any dossier may remain."""
        return self._guard_report(text, primary)[0]

    def _guard_report(self, text: str, primary: Optional[Dossier] = None) -> tuple[str, Counter]:
        """``_guard`` that also counts the values it replaced, per kind."""
        out, _steps, replaced = self._guard_full(text, primary)
        return out, replaced

    def _guard_full(self, text: str, primary: Optional[Dossier] = None
                    ) -> tuple[str, Optional[list[_Alignment]], Counter]:
        """The last canary, with one alignment per dossier pass (None when the NFC form changed the length).

        ``primary`` is the dossier the text belongs to: its own values get their codes, values of other dossiers
        become new entities of ``primary`` (restorable), and single common words of other dossiers stay."""
        replaced: Counter = Counter()
        steps: Optional[list[_Alignment]] = []
        if not text:
            return text, steps, replaced
        nfc = _nfc(text)
        if nfc != text:
            text, steps = nfc, None
        prep: Optional[ScanPrep] = None
        for d in self._open_dossiers():
            if not d.all():
                continue
            if prep is None:
                prep = prepare_scan(text)
            hits = self._leftovers(d, text, prep)
            own = primary is not None and d.code == primary.code
            if hits and primary is not None and not own:
                hits = [h for h in hits if self._foreign_hit(d, text, h)]
            if hits:
                log.warning("RAGbase Shield: %d leftover value(s) of %s replaced in an output", len(hits), d.code)
                text, edits = self._redact(text, hits, d, own=own, mint_into=primary)
                replaced.update(h.kind for h in hits)
                if steps is not None:
                    steps.append(_edits_alignment(edits))
                prep = None  # the text changed: prepare it again for the next dossier
        return text, steps, replaced

    def _has_registered(self, text: str, primary: Optional[Dossier] = None) -> bool:
        """True when ``text`` holds a registered value of any dossier (cheap check, no masking). With
        ``primary``, single common words of other dossiers do not count (same rule as :meth:`_guard`)."""
        if not text:
            return False
        if primary is None:
            primary = self._context_dossier()
        text = _nfc(text)
        prep: Optional[ScanPrep] = None
        for d in self._open_dossiers():
            if not d.all():
                continue
            if prep is None:
                prep = prepare_scan(text)
            hits = self._leftovers(d, text, prep)
            if hits and primary is not None and d.code != primary.code:
                hits = [h for h in hits if self._foreign_hit(d, text, h)]
            if hits:
                return True
        return False

    def _context_dossier(self) -> Optional[Dossier]:
        """The dossier set by :func:`output_dossier` around the current call, if any (and still registered)."""
        code = _OUTPUT_DOSSIER.get()
        if not code or not DOSSIER_RE.match(code):
            return None
        try:
            return self.registry.get(code)
        except UnknownDossier:
            return None

    def _guard_epoch(self) -> tuple:
        """Revisions of every dossier: a cached document is guarded again when one of them changed."""
        return tuple((d.code, d.revision) for d in self._open_dossiers())

    def _guard_many(self, items: list[str], primary: Optional[Dossier] = None) -> list[str]:
        """``_guard`` on many short strings at once (one canary pass per dossier)."""
        if not items:
            return items
        sep = "\n|\n"
        if not any(sep in x for x in items):
            joined = self._guard(sep.join(items), primary)
            parts = joined.split(sep)
            if len(parts) == len(items):
                return parts
        return [self._guard(x, primary) for x in items]

    def _registered_in(self, d: Dossier, text: str, prep: Optional[ScanPrep] = None) -> list[dict]:
        """Registered entities of ``d`` present in ``text``: [{code, kind, dossier}] (code None if unsure)."""
        lenient = self._leftovers(d, text, prep)
        if not lenient:
            return []
        dry = _DryStore(d)
        res = Masker(dry, locale=d.locale, use_ner=False).mask(text)
        real_codes = {e.code for e in d.all()}
        before = Counter(m.group() for m in UNMASK_RE.finditer(text))
        after = Counter(m.group() for m in UNMASK_RE.finditer(res.text))
        out: list[dict] = []
        seen: set[str] = set()
        for m in UNMASK_RE.finditer(res.text):
            code = m.group()
            if code in real_codes and after[code] > before.get(code, 0) and code not in seen:
                ent = d.get_by_code(code)
                if ent is not None and not d.is_kept_clear(ent.norm):
                    seen.add(code)
                    out.append({"code": code, "kind": ent.kind, "dossier": d.code})
        covered = [(s.start, s.end) for s in res.spans]
        for s in lenient:
            if any(a < s.end and s.start < b for a, b in covered):
                continue
            ent = self._entity_for(d, s.kind, s.value)
            code = ent.code if ent is not None else None
            if code is not None and code in seen:
                continue
            if code is not None:
                seen.add(code)
            out.append({"code": code, "kind": s.kind, "dossier": d.code})
        return out

    # ---------------------------------------------------------------- documents
    def _pdf_pages(self, path: Path, mtime_ns: int, size: int) -> Optional[int]:
        key = (str(path), mtime_ns, size)
        if key not in self._pages:
            pages = None
            try:
                from pypdf import PdfReader

                reader = PdfReader(str(path))
                if reader.is_encrypted:
                    reader.decrypt("")
                pages = len(reader.pages)
            except Exception:  # noqa: BLE001 - a page count is optional
                pages = None
            self._pages[key] = pages
        return self._pages[key]

    def _doc(self, d: Dossier, ref: Any, fresh: bool, epoch: Optional[tuple] = None) -> _CachedDoc:
        """Masked document from the cache, or read + masked now. ``fresh`` re-masks when the dossier changed.

        The cached text is the masked text after the last canary of every dossier (R1 correction CL-25): the
        offsets of ``read_document`` and the alignment used by ``search`` are those of the text the model reads,
        so a raw word the canary hid can never be confirmed by a search hit."""
        key = (d.code, ref.id)
        st = ref.path.stat()
        cached = self._docs.get(key)
        if cached is not None and cached.mtime_ns == st.st_mtime_ns and cached.size == st.st_size:
            if not fresh or cached.version == self._version(d):
                now = epoch if epoch is not None else self._safe_epoch()
                if now is not None and cached.epoch != now:
                    current = cached.version == self._version(d)
                    self._guard_doc(d, cached)
                    if current:  # only the canary's own new codes changed the dossier
                        cached.version = self._version(d)
                self._docs.move_to_end(key)
                return cached
        raw = documents.read_text(ref.path)
        if len(raw.text) > MAX_DOCUMENT_CHARS:
            raise ShieldError(f"{ref.id} est trop volumineux pour être lu (plus de {MAX_DOCUMENT_CHARS:,} caractères) "
                              "(document_too_large).".replace(",", " "), "document_too_large")
        m = self._masker(d)
        if raw.needs_ocr or not raw.text:
            masked, alignment = "", _Alignment()
        else:
            res = m.mask(raw.text)
            masked = res.text
            if res.mode == "synthetic":  # v0.2: the edits are known exactly, no code to find in the text
                alignment = _edits_alignment(sorted(zip((sp.start for sp in res.spans), (sp.end for sp in res.spans),
                                                        res.replacements)))
            else:
                alignment = _align(raw.text, masked, res.spans, {e.code for e in d.all()})
            if alignment is None:
                log.info("RAGbase Shield: %s %s: offsets not aligned; search uses the masked text", d.code, ref.id)
        entry = _CachedDoc(mtime_ns=st.st_mtime_ns, size=st.st_size, version=self._version(d), raw=raw.text,
                           masked=masked, alignment=None, needs_ocr=bool(raw.needs_ocr),
                           pages=raw.pages, warnings=tuple(raw.warnings), masked0=masked, align0=alignment)
        self._guard_doc(d, entry)
        entry.version = self._version(d)  # the canary may have given new codes to this dossier
        self._docs[key] = entry
        self._docs.move_to_end(key)
        while len(self._docs) > _CACHE_DOCS:
            self._docs.popitem(last=False)
        return entry

    def _guard_doc(self, d: Dossier, entry: _CachedDoc) -> None:
        """Run the last canary on a whole cached document and chain its edits to the masker alignment.

        When the vault of another dossier cannot be opened, the document stays unguarded in the cache (a scan
        still works); every model-facing read or search then fails closed on the same vault."""
        try:
            guarded, steps, _n = self._guard_full(entry.masked0, d)
            epoch = self._guard_epoch()
        except ShieldError as exc:
            if exc.kind != "vault_error":
                raise
            guarded, steps, epoch = entry.masked0, [], ()
        entry.masked = guarded
        entry.alignment = _Chain([entry.align0] + steps) if entry.align0 is not None and steps is not None else None
        entry._folded_masked = None
        entry.epoch = epoch

    def _safe_epoch(self) -> Optional[tuple]:
        """:meth:`_guard_epoch`, or None when a vault cannot be opened."""
        try:
            return self._guard_epoch()
        except ShieldError as exc:
            if exc.kind != "vault_error":
                raise
            return None

    def _mask_label(self, d: Optional[Dossier], text: str) -> str:
        """Mask a short label (file or folder name): the dossier rules, then a word-by-word pass that also
        catches names glued by hyphens, digits or capitals ("Kervadec-c-Veltrane", "MaelleKervadec",
        "Kervadec2026", "kervadec's notes") for the registered values of every dossier."""
        if not text:
            return text
        spaced = _nfc(text).replace("_", " ")
        if d is not None:
            masked = self._rules(d).mask(spaced).text
        else:
            masked = Masker(MemoryStore(locale=config.locale()), locale=config.locale(), use_ner=False).mask(spaced).text
        return self._label_pass(masked, d)

    def _label_index(self, d: Dossier) -> dict:
        """Name words of the dossier's people and companies, for :meth:`_label_pass` (cached per version)."""
        rev = d.revision
        cached = self._label_indexes.get(d.code)
        if cached is not None and cached[0] == rev:
            return cached[1]
        from .engine import names as nm

        stop, legal, common, _fn, afn, months, wl = nm._lists()
        strong: dict[str, set[str]] = {}
        weak: dict[str, set[str]] = {}
        weak_surname: dict[str, set[str]] = {}
        first: dict[str, set[str]] = {}
        acro: dict[str, set[str]] = {}
        initials: dict[str, set[str]] = {}

        def classify(tok: str, code: str, surname: bool = False) -> None:
            if len(tok) < 3 or tok in stop or tok in legal or tok in months or tok in wl or tok in nm.LEGAL_FORMS \
                    or tok in nm.ORG_GENERIC or tok in nm.TITLE_WORDS or tok in nm.PARTICLES:
                return
            is_weak = tok in common or tok in afn or len(tok) < 4
            (weak if is_weak else strong).setdefault(tok, set()).add(code)
            if is_weak and surname and len(tok) >= 4:
                weak_surname.setdefault(tok, set()).add(code)

        for e in d.all():
            if e.kind == "PERSON":
                for tok in nm.surname_key(e.value).split():
                    classify(tok, e.code, surname=True)
                for tok in nm.first_key(e.value).split():
                    if len(tok) >= 3:
                        first.setdefault(tok, set()).add(e.code)
                for ini in _person_initials(e.value):
                    initials.setdefault(ini, set()).add(e.code)
            elif e.kind == "ORG":
                for tok in _safe_norm("ORG", e.value).split():
                    classify(tok, e.code)
                for a in _org_acronyms(e.value):
                    acro.setdefault(a, set()).add(e.code)
        index = {"strong": strong, "weak": weak, "first": first, "weak_surname": weak_surname, "acro": acro,
                 "initials": initials}
        self._label_indexes[d.code] = (rev, index)
        return index

    def _label_pass(self, label: str, primary: Optional[Dossier]) -> str:
        """Replace the words of a label that are registered names of any dossier (own dossier: the code)."""
        toks = _label_tokens(label)
        if not toks:
            return label
        from .engine.normalize import fold_word

        folded = [fold_word(label[a:b]) for a, b in toks]
        hit: list[Optional[tuple[frozenset, Dossier]]] = [None] * len(toks)
        tails: dict[int, int] = {}  # last token of dotted initials -> end of the match (its final dot)
        for d in self._open_dossiers():
            if not d.all():
                continue
            idx = self._label_index(d)
            for i, (a, b) in enumerate(toks):
                if hit[i] is not None:
                    continue
                f = folded[i]
                codes = idx["strong"].get(f)
                if not codes and len(f) >= 4 and label[a:b].isupper():
                    codes = idx["weak"].get(f)
                if codes:
                    codes = {c for c in codes if not self._code_kept(d, c)}
                if codes:
                    hit[i] = (frozenset(codes), d)
            if primary is not None and d.code == primary.code:
                tails.update(self._own_label_forms(label, toks, folded, hit, d, idx))
            for i, f in enumerate(folded):  # a first name next to its own surname: "MaelleKervadec"
                if hit[i] is not None or f not in idx["first"]:
                    continue
                for j in (i - 1, i + 1):
                    if 0 <= j < len(toks) and hit[j] is not None and hit[j][1] is d \
                            and idx["first"][f] & hit[j][0] and _label_glue(label, toks, min(i, j)):
                        hit[i] = (frozenset(idx["first"][f] & hit[j][0]), d)
                        break
        if not any(hit):
            return label
        out: list[str] = []
        pos = 0
        i = 0
        while i < len(toks):
            if hit[i] is None:
                i += 1
                continue
            j = i
            while j + 1 < len(toks) and hit[j + 1] is not None and hit[j + 1] == hit[i] and _label_glue(label, toks, j):
                j += 1
            codes, d = hit[i]
            code = next(iter(codes)) if len(codes) == 1 else None
            ent = d.get_by_code(code) if code else d.get_by_code(next(iter(codes)))
            kind = ent.kind if ent is not None else "PERSON"
            own = primary is not None and d.code == primary.code and code is not None
            rep = code if own else None
            if rep is None and primary is not None and d.code != primary.code:
                # a name of another dossier in this dossier's label: a new, restorable code of this dossier (CL-26)
                minted = self._mint(primary, kind, label[toks[i][0]:toks[j][1]])
                rep = minted.code if minted is not None else None
            out.append(label[pos:toks[i][0]])
            out.append(rep or f"[{prefix_for(kind, d.locale)}]")
            pos = max(toks[j][1], tails.get(j, 0))
            i = j + 1
        out.append(label[pos:])
        return "".join(out)

    def _own_label_forms(self, label: str, toks: list[tuple[int, int]], folded: list[str],
                         hit: list, d: Dossier, idx: dict) -> dict[int, int]:
        """Short forms of the dossier's OWN entities in a label (R1 corrections CL-01, CL-02, CL-05).

        - an upper-case group of 3 to 6 letters that is the acronym of exactly one registered company
          ("Data room XQV", "XQV-310"), or of 3 or 4 letters that is the initials of exactly one registered
          person;
        - dotted initials ("R.T.", "J.-B. W.") of registered persons;
        - a capitalised surname that is also a common word or a first name ("Bulletins Serrurier 2024"), when
          exactly one person of the dossier has it as a surname and no other one as a first name.
        Only names already known in the dossier count: a short form is never guessed from nothing.
        Returns {index of the last token of dotted initials: end of the match}, so the final dot goes too."""
        tails: dict[int, int] = {}
        for i, (a, b) in enumerate(toks):
            if hit[i] is not None:
                continue
            f, surface = folded[i], label[a:b]
            codes: set[str] = set()
            if surface.isalpha() and surface.isupper() and 3 <= len(f) <= 6:
                codes = set(idx["acro"].get(f, ())) | (set(idx["initials"].get(f, ())) if len(f) <= 4 else set())
                if len(codes) != 1:
                    codes = set()
            elif len(f) >= 4 and surface[:1].isupper() and surface[1:].islower():
                owners = idx["weak_surname"].get(f, set())
                if len(owners) == 1 and not (idx["first"].get(f, set()) - owners):
                    codes = set(owners)
            codes = {c for c in codes if not self._code_kept(d, c)}
            if codes:
                hit[i] = (frozenset(codes), d)
        for m in _DOTTED_INITIALS_RE.finditer(label):
            letters = re.sub(r"[^A-Za-z]", "", m.group()).lower()
            if _weak_word(letters):
                continue  # "S.A." is a legal form, not a person
            codes = {c for c in idx["initials"].get(letters, ()) if not self._code_kept(d, c)}
            inside = [i for i, (a, b) in enumerate(toks) if a >= m.start() and b <= m.end()]
            if codes and inside and all(hit[i] is None for i in inside):
                for i in inside:
                    hit[i] = (frozenset(codes), d)
                tails[inside[-1]] = m.end()
        return tails

    @staticmethod
    def _code_kept(d: Dossier, code: str) -> bool:
        ent = d.get_by_code(code)
        return bool(ent is not None and d.is_kept_clear(ent.norm))

    def _clean_label(self, d: Optional[Dossier], label: str, fallback: str) -> str:
        """A masked label that is safe to show or to use as a download name; ``fallback`` when the canary
        still finds a registered value in it."""
        masked = self._guard(self._mask_label(d, label), d)
        with output_dossier(d.code if d is not None else None):
            still = self._has_registered(masked)
        if still:
            return fallback
        return masked

    # ================================================================ model-facing API
    @_guarded("list_dossiers")
    def list_dossiers(self, include_private: bool = False) -> list[dict]:
        """[{code, documents, entities}] (codes only). ``include_private`` adds title and folder (local only)."""
        with self._lock:
            out = []
            for code in self.registry.folders():
                try:
                    d = self.registry.get(code)
                    row: dict[str, Any] = {"code": d.code, "documents": len(d.documents()), "entities": len(d.all())}
                    if include_private:
                        row.update(title=d.title, folder=str(d.folder), replacement=self._dossier_replacement(d))
                except VaultError:
                    row = {"code": code, "documents": None, "entities": None, "error": "vault_unreadable"}
                out.append(row)
            return out

    @_guarded("list_documents")
    def list_documents(self, dossier_code: str) -> list[dict]:
        """[{id, masked_name, masked_path, kind, size, pages}] with masked file names.

        Files Shield cannot read (spreadsheets, images...) are listed too, with kind ``"unsupported"`` (R1
        correction CL-28): the model can tell the user a file exists and ask for a readable copy."""
        with self._lock:
            d = self._dossier(dossier_code)
            refs = d.documents(include_unsupported=True)
            labels: list[str] = []
            rows = []
            for ref in refs:
                stem, ext = os.path.splitext(ref.name)
                parent = Path(ref.rel).parent.as_posix() if ref.rel else "."
                parts = [] if parent in ("", ".") else parent.split("/")
                first = len(labels)
                labels.extend(self._mask_label(d, p) for p in parts)
                labels.append(self._mask_label(d, stem))
                rows.append((ref, ext.lower(), first, len(labels)))
            labels = self._guard_many(labels, d)
            out = []
            for ref, ext, a, b in rows:
                masked_name = labels[b - 1] + ext
                pages = None
                if ref.kind == "pdf":
                    cached = self._docs.get((d.code, ref.id))
                    pages = cached.pages if cached is not None and cached.pages is not None else \
                        self._pdf_pages(ref.path, ref.path.stat().st_mtime_ns, ref.size)
                out.append({"id": ref.id, "masked_name": masked_name,
                            "masked_path": "/".join(labels[a:b - 1] + [masked_name]),
                            "kind": ref.kind, "size": ref.size, "pages": pages})
            d.journal("list_documents", documents=len(out))
            return out

    @_guarded("read_document")
    def read_document(self, dossier_code: str, doc_id: str, start: int = 0,
                      max_chars: int = DEFAULT_READ_CHARS) -> dict:
        """One page of a masked document: {id, text, start, next, total_chars, needs_ocr, pages, warnings}."""
        with self._lock:
            d = self._dossier(dossier_code)
            doc = _doc_code(doc_id)
            ref = d.get_document(doc)
            if ref is None:
                other = d.get_document(doc, include_unsupported=True)
                if other is not None and other.kind == UNSUPPORTED_KIND:
                    raise ShieldError(f"{doc} : format non pris en charge, Shield ne peut pas lire ce fichier. "
                                      "Demandez à l'utilisateur une copie en PDF, Word ou texte "
                                      "(unsupported_format).", "unsupported_format")
                raise ShieldError(f"{doc} introuvable dans {d.code} (unknown document). "
                                  "Appelez shield_list_documents.", "unknown_document")
            try:
                start = max(0, int(start or 0))
                max_chars = int(max_chars or DEFAULT_READ_CHARS)
            except (TypeError, ValueError):
                raise ShieldError("start et max_chars doivent être des nombres (must be integers).",
                                  "invalid_argument") from None
            max_chars = min(MAX_READ_CHARS, max(MIN_READ_CHARS, max_chars))
            entry = self._doc(d, ref, fresh=start == 0)
            total = len(entry.masked)
            if start >= total:
                page, end = "", total
            else:
                end = _cut(entry.masked, start, max_chars)
                page = entry.masked[start:end]
            d.journal("read_document", document=ref.id, chars=len(page))
            return {"id": ref.id, "text": self._guard(page, d), "start": min(start, total),
                    "next": end if end < total else None, "total_chars": total,
                    "needs_ocr": entry.needs_ocr, "pages": entry.pages, "warnings": list(entry.warnings)}

    @_guarded("search")
    def search(self, dossier_code: str, query: str, limit: int = DEFAULT_SEARCH_RESULTS) -> list[dict]:
        """Search the dossier locally. Codes in the query match every masked mention of that entity; other
        words are searched in the real text, case and accent insensitive. Returns masked snippets:
        [{document, snippet, offset}] where ``offset`` is a ``start`` for ``read_document``."""
        with self._lock:
            d = self._dossier(dossier_code)
            q = " ".join(str(query or "").split())
            if not q:
                raise ShieldError("Recherche vide (empty query).", "invalid_argument")
            if len(q) > MAX_QUERY_CHARS:
                raise ShieldError(f"Recherche trop longue (max {MAX_QUERY_CHARS} caractères).", "invalid_argument")
            try:
                limit = min(MAX_SEARCH_RESULTS, max(1, int(limit or DEFAULT_SEARCH_RESULTS)))
            except (TypeError, ValueError):
                limit = DEFAULT_SEARCH_RESULTS
            m = self._masker(d)
            codes = []
            for cm in UNMASK_RE.finditer(q):
                if d.get_by_code(cm.group()) is not None and cm.group() not in codes:
                    codes.append(cm.group())
            plain = UNMASK_RE.sub(" ", q)
            terms = [t for t in dict.fromkeys(fold(plain).text.split()) if len(t) >= 3]
            # A phrase with codes is searched in the MASKED text, where real values never appear: a code next
            # to a guessed name can never confirm the guess.
            phrase = fold(q).text.strip() if codes else fold(plain).text.strip()
            terms = [t for t in terms if t not in _STOPWORDS] or terms
            hits: list[tuple[int, int, str, int, int]] = []  # (-score, doc order, doc id, mstart, mend)
            epoch = self._guard_epoch()
            for order, ref in enumerate(d.documents()):
                try:
                    entry = self._doc(d, ref, fresh=False, epoch=epoch)
                except documents.DocumentError:
                    continue
                except ShieldError as exc:
                    if exc.kind == "document_too_large":
                        continue
                    raise
                if not entry.masked:
                    continue
                found = self._search_doc(entry, phrase, codes, terms, bool(codes))
                for score, ms, me in _score_hits(found):
                    hits.append((-score, order, ref.id, ms, me))
            hits.sort()
            out: list[dict] = []
            taken: dict[str, list[tuple[int, int]]] = {}
            for neg, _order, doc_id, ms, me in hits:
                if len(out) >= limit:
                    break
                spans = taken.setdefault(doc_id, [])
                if any(a <= ms < b or a < me <= b for a, b in spans):
                    continue
                entry = self._docs[(d.code, doc_id)]
                a = _snap_left(entry.masked, max(0, ms - SNIPPET_RADIUS), 40)
                b = _snap_right(entry.masked, min(len(entry.masked), me + SNIPPET_RADIUS), 40)
                spans.append((a, b))
                snippet = ("…" if a > 0 else "") + " ".join(entry.masked[a:b].split()) + \
                          ("…" if b < len(entry.masked) else "")
                out.append({"document": doc_id, "snippet": self._guard(snippet, d), "offset": a})
            d.journal("search", results=len(out))
            return out

    @staticmethod
    def _find(folded_text: str, needle: str) -> Iterable[tuple[int, int]]:
        if not needle:
            return []
        pat = re.compile(r"(?<![a-z0-9])" + re.escape(needle) + r"(?![a-z0-9])")
        return [(mm.start(), mm.end()) for mm in pat.finditer(folded_text)]

    def _search_doc(self, entry: _CachedDoc, phrase: str, codes: list[str], terms: list[str],
                    phrase_has_codes: bool) -> list[tuple[int, str, int, int]]:
        """(weight, item, masked start, masked end) of every match in one document."""
        found: list[tuple[int, str, int, int]] = []
        al = entry.alignment
        if phrase_has_codes:
            fm = entry.folded_masked
            for fs, fe in self._find(fm.text, phrase):
                s, e = fm.span(fs, fe)
                found.append((6, "\0phrase", s, e))
        if al is not None and entry.raw:
            fr = entry.folded_raw

            def visible(s: int, e: int, needle: str) -> Optional[tuple[int, int]]:
                """Masked offsets of a raw hit, only when the model sees the same words there (CL-25): a word
                hidden by the masker or by the last canary never yields a hit."""
                if al.overlaps(s, e):
                    return None  # a plain word inside a masked value: never confirm a guess
                ms, me = al.to_masked(s), al.to_masked(e)
                if fold(entry.masked[ms:me]).text.strip() != needle:
                    return None
                return ms, me

            for fs, fe in ([] if phrase_has_codes else self._find(fr.text, phrase)):
                pos = visible(*fr.span(fs, fe), phrase)
                if pos is not None:
                    found.append((6, "\0phrase", pos[0], pos[1]))
            for term in terms:
                for fs, fe in self._find(fr.text, term):
                    pos = visible(*fr.span(fs, fe), term)
                    if pos is not None:
                        found.append((1, term, pos[0], pos[1]))
        else:
            fm = entry.folded_masked
            if not phrase_has_codes:
                for fs, fe in self._find(fm.text, phrase):
                    s, e = fm.span(fs, fe)
                    found.append((6, "\0phrase", s, e))
            for term in terms:
                for fs, fe in self._find(fm.text, term):
                    s, e = fm.span(fs, fe)
                    found.append((1, term, s, e))
        for code in codes:
            for mm in re.finditer(r"(?<![A-Za-z0-9])" + re.escape(code) + r"(?![A-Z0-9])", entry.masked):
                found.append((2, code, mm.start(), mm.end()))
        return found

    @_guarded("save_draft")
    def save_draft(self, dossier_code: str, title: str, content: str, fmt: str = "docx") -> dict:
        """Restore the codes locally and write the file into ``<dossier>/Shield - sorties``.

        Returns {id: OUTPUT_n, bytes, format, unknown_codes} only: never the path or the restored text.
        :meth:`save_draft_report` also lists what could not be restored.
        """
        r = self.save_draft_report(dossier_code, title, content, fmt)
        return {k: r[k] for k in ("id", "bytes", "format", "unknown_codes")}

    @_guarded("save_draft")
    def save_draft_report(self, dossier_code: str, title: str, content: str, fmt: str = "docx") -> dict:
        """:meth:`save_draft` that also returns ``placeholders`` (generic marks left in the file, one entry per
        occurrence, "[SOCIETE]") and ``shield_ids`` (DOC_n / DOSSIER_n / OUTPUT_n that got no local name): R1
        corrections CL-31 and CL-36. Codes and generic marks only, never a value or a label."""
        with self._lock:
            d = self._dossier(dossier_code)
            fmt = str(fmt or "docx").strip().lower().lstrip(".")
            if fmt not in ("docx", "md"):
                raise ShieldError("Format inconnu : docx ou md (unknown format).", "invalid_argument")
            content = str(content or "")
            if not content.strip():
                raise ShieldError("Contenu vide (empty content).", "invalid_argument")
            if len(content) > MAX_DRAFT_CHARS:
                raise ShieldError("Contenu trop long (content too long).", "invalid_argument")
            title = " ".join(str(title or "").split())[:MAX_TITLE_CHARS] or "Projet"
            m = self._masker(d)
            labels = self._id_labels(d, title + "\n" + content)
            body = self._restore_out(m, content, labels)
            head = self._restore_out(m, title, labels, max_chars=getattr(documents, "MAX_STEM_CHARS", None))
            unknown_all = list(dict.fromkeys(body["unknown_codes"] + head["unknown_codes"]))
            placeholders = body["placeholders"] + head["placeholders"]
            shield_ids = list(dict.fromkeys(body["shield_ids"] + head["shield_ids"]))
            try:
                path = documents.save_output(d.output_dir(), head["text"], body["text"], fmt, d.code)
            except (OSError, documents.DocumentError):
                raise ShieldError(f"Écriture impossible dans le dossier de sortie de {d.code} (write_failed).",
                                  "write_failed") from None
            oid = d.register_output(path)
            size = path.stat().st_size
            d.journal("save_draft", output=oid, format=fmt, bytes=size, unknown_codes=len(unknown_all),
                      placeholders=len(placeholders), shield_ids=len(shield_ids))
            # Codes and generic marks only: the labels used for DOC_n / DOSSIER_n / OUTPUT_n never leave.
            return {"id": oid, "bytes": size, "format": fmt, "unknown_codes": unknown_all,
                    "placeholders": placeholders, "shield_ids": shield_ids}

    def _id_labels(self, d: Dossier, text: str) -> dict[str, str]:
        """Local names of the Shield ids a draft cites (R1 correction CL-36): DOC_n -> file name, the dossier's
        own DOSSIER_n -> its title, OUTPUT_n -> output file name. REAL values: for the restored local file only,
        never returned to a model. Ids of other dossiers and unknown ids get no label."""
        labels: dict[str, str] = {}
        for sid in dict.fromkeys(_SHIELD_ID_RE.findall(text or "")):
            name: Optional[str] = None
            if sid.startswith("DOC_"):
                ref = d.get_document(sid, include_unsupported=True)
                name = ref.name if ref is not None else None
            elif sid.startswith("DOSSIER_"):
                name = d.title if sid == d.code else None
            else:
                out = d.get_output(sid)
                name = out.name if out is not None else None
            if name:
                labels[sid] = name
        return labels

    @staticmethod
    def _restore_out(m: Masker, text: str, id_labels: dict[str, str], max_chars: Optional[int] = None) -> dict:
        """Restore ``text`` for a LOCAL output: {text, unknown_codes, placeholders, shield_ids, restored}.

        Uses ``restore_utils.restore_for_output`` (R1 RESTORE corrections: line breaks, elision, Shield ids...)
        when it is installed; otherwise the masker's restore, with the same report of the generic placeholders
        and Shield ids left in the text (R1 correction CL-31)."""
        helper = _restore_for_output()
        if helper is not None:
            kwargs: dict[str, Any] = {"id_labels": id_labels or None}
            if max_chars:
                kwargs["max_chars"] = max_chars
            rep = helper(text, m, **kwargs)
            return {"text": rep.text, "unknown_codes": list(rep.unknown_codes),
                    "placeholders": list(rep.placeholders), "shield_ids": list(dict.fromkeys(rep.shield_ids)),
                    "restored": int(rep.restored),
                    "restored_synthetic": int(getattr(rep, "restored_synthetic", 0)),
                    "unmatched_synthetic": int(getattr(rep, "unmatched_synthetic", 0))}
        real, unknown = m.unmask_report(text)
        return {"text": real, "unknown_codes": list(unknown), "placeholders": _PLACEHOLDER_RE.findall(text),
                "shield_ids": list(dict.fromkeys(_SHIELD_ID_RE.findall(text))),
                "restored": sum(1 for mm in UNMASK_RE.finditer(text) if m.store.get_by_code(mm.group()) is not None)}

    @_guarded("scan_text")
    def scan_text(self, text: str) -> list[dict]:
        """Canary across ALL dossiers: [{code, kind, dossier}] of the registered values found in ``text``.

        ``code`` is None when the canary found a value (for example an OCR variant) but cannot tell which
        entity it is. Never returns a value.
        """
        with self._lock:
            text = _nfc(str(text or ""))
            if not text:
                return []
            out: list[dict] = []
            prep: Optional[ScanPrep] = None
            for d in self._open_dossiers():
                if not d.all():
                    continue
                if prep is None:
                    prep = prepare_scan(text)
                out.extend(self._registered_in(d, text, prep))
            return out

    @_guarded("has_registered")
    def has_registered(self, text: str) -> bool:
        """True when ``text`` holds a registered value of any dossier (hooks: cheap first check)."""
        with self._lock:
            return self._has_registered(str(text or ""))

    @_guarded("status")
    def status(self) -> dict:
        """{version, engine_mode, locale, language, ner, dossiers, key_storage, ocr, limits, replacement}. Codes
        and counts only (the NER block names packages, models and the models directory, never a dossier)."""
        with self._lock:
            mode = Masker(MemoryStore(), locale=config.locale(), ner_model=config.ner_model()).mode
            try:
                st = _ner.status(config.ner_model())
                ner_info = {"setting": st["setting"], "model_setting": st["model_setting"], "backend": st["backend"],
                            "loaded": bool(st["loaded"]), "max_chars": st["max_chars"],
                            "models": {k: bool(m["cached"]) for k, m in st["models"].items()},
                            "models_dir": st["models_dir"]}
            except Exception:  # noqa: BLE001 - status never fails on the optional layer
                ner_info = {"setting": "auto", "backend": None, "loaded": False, "models": {}}
            return {"version": __version__, "engine_mode": mode, "locale": config.locale(),
                    "language": config.language(), "ner": ner_info,
                    "dossiers": len(self.registry.folders()), "key_storage": self.registry.key_source,
                    "ocr": False, "network": False,
                    "replacement": config.replacement(), "replacements": ["codes", "synthetic"],
                    "own_company_vendor": config.own_company_vendor(),
                    "limits": [fr for fr, _en in LIMITS], "limits_en": [en for _fr, en in LIMITS]}

    # ================================================================ hook support
    @_guarded("guard_output")
    def guard_output(self, text: str, dossier_code: Optional[str] = None) -> str:
        """Last canary for any model-facing string: registered values of any dossier become ``[PERSONNE]``...

        With a dossier (argument, or :func:`output_dossier` around the call), the text belongs to that dossier:
        its values get their codes and values of other dossiers new codes of it (R1 correction CL-26)."""
        with self._lock:
            if dossier_code:
                with output_dossier(dossier_code):
                    primary = self._context_dossier()
            else:
                primary = self._context_dossier()
            return self._guard(str(text or ""), primary)

    @_guarded("protect")
    def protect(self, text: str) -> tuple[str, list[str]]:
        """Mask every registered value left in ``text`` (any dossier). Returns (text, codes added).

        For outputs that did not come from Shield (other tools' results). The dossier with the most hits is
        masked with its own masker (so names found next to its values are masked too, and added to it);
        codes already in the text are kept. Values of other dossiers, and values the strict masker misses
        (OCR variants), are replaced by the canary.
        """
        with self._lock:
            original = text = _nfc(str(text or ""))
            if not text:
                return text, []
            ranked = []
            prep: Optional[ScanPrep] = None
            for d in self._open_dossiers():
                if not d.all():
                    continue
                if prep is None:
                    prep = prepare_scan(text)
                hits = self._leftovers(d, text, prep)
                if hits:
                    ranked.append((len(hits), d))
            if not ranked:
                return text, []
            ranked.sort(key=lambda x: (-x[0], x[1].num))
            first = ranked[0][1]
            res = self._rules(first).mask(text, keep_known_codes=True)
            text = res.text
            if res.new_entities:
                self._invalidate(first.code)
            prep = None
            for _n, d in ranked:
                if prep is None:
                    prep = prepare_scan(text)
                left = self._leftovers(d, text, prep)
                if left:
                    text = self._redact(text, left, d, own=d.code == first.code)[0]
                    prep = None
            before = Counter(mm.group() for mm in UNMASK_RE.finditer(original))
            added = []
            for mm in UNMASK_RE.finditer(text):
                code = mm.group()
                if code not in added and text.count(code) > before.get(code, 0):
                    added.append(code)
            return text, added

    # ================================================================ local API (Desk, CLI)
    @_guarded("add_dossier")
    def add_dossier(self, folder: os.PathLike | str, title: Optional[str] = None) -> dict:
        """Register a folder, scan its documents and register the parties named in the title ("X c. Y").

        Returns {code, documents, entities, counts, parties, unreadable, needs_ocr}. Codes and counts only.
        """
        with self._lock:
            existed = self.registry.is_registered(folder)
            d = self.registry.add_dossier(folder, title)
            typed = bool(title and title.strip())
            title_changed = False
            if existed and typed and normalize(" ".join(title.split())) != normalize(d.title):
                # The folder was already registered and the user typed a new title: keep it and read its parties.
                self.registry.set_title(d.code, title)
                title_changed = True
            try:
                summary = self._scan(d)
            except BaseException:
                if not existed:  # never leave a half-made dossier behind
                    try:
                        self.registry.remove(d.code)
                    except Exception:  # noqa: BLE001
                        log.warning("RAGbase Shield: %s could not be rolled back after a failed scan", d.code)
                    self._drop_maskers(d.code)
                    self._rule_maskers.pop(d.code, None)
                    self._invalidate(d.code)
                raise
            added = 0
            # A typed title is parsed for parties. The folder-name fallback ("Dossier Ferracci-Daubel") is
            # parsed only when it names opposing parties ("X c. Y"), so a description never becomes a person.
            source = d.title if (typed or has_party_separator(d.title)) else ""
            for kind, name in parse_parties(source):
                if self._party_known(d, kind, name):
                    continue
                try:
                    d.register(kind, name)
                    added += 1
                except ValueError:
                    continue
            if added:
                self._invalidate(d.code)
            d.journal("add_dossier", parties=added, documents=summary["documents"])
            summary.update(code=d.code, parties=added, entities=len(d.all()), counts=_kind_counts(d),
                           existing=existed, title_updated=title_changed)
            return summary

    def _party_known(self, d: Dossier, kind: str, name: str) -> bool:
        """True when a title party is already one of the dossier's entities, under ANY kind: "Ateliers Brunelac"
        typed as a person is the company the documents found; "Kerdalis" is the company "KERDALIS INDUSTRIES"."""
        for k in ("PERSON", "ORG"):
            if self._same_entity(d, k, name) is not None:
                return True
        other = "ORG" if kind == "PERSON" else "PERSON"
        if self._links_to_known(d, kind, name) or self._links_to_known(d, other, name):
            return True
        words = fold(name).text.split()
        if len(words) == 1:
            for e in d.all():
                if e.kind == "ORG" and _safe_norm("ORG", e.value).split()[:1] == words:
                    return True
        return False

    def _links_to_known(self, d: Dossier, kind: str, name: str) -> bool:
        """True when ``name`` is already covered by one known entity of the same kind (no new code needed)."""
        if not d.all():
            return False
        store = _DryStore(d)
        res = Masker(store, locale=d.locale, use_ner=False).mask(name)
        if _SENTINEL_RE.search(res.text) or not res.spans:
            return False
        kinds = {d.get_by_code(mm.group()).kind for mm in UNMASK_RE.finditer(res.text) if d.get_by_code(mm.group())}
        if kinds != {kind}:
            return False
        rest = UNMASK_RE.sub(" ", res.text)
        return not re.search(r"[^\W\d_]{4,}", rest) or _only_forms(rest)

    def _build_directory(self, d: Dossier) -> int:
        """Build the dossier directory from the folder (e-mail headers, Slack ``users.json``, Word authors,
        signature blocks, nickname declarations), store it in the vault and seed the store with every full name,
        before the documents are masked (v0.3, S3). Never fails a scan: on any error the dossier keeps its
        previous directory. Returns the number of people found."""
        set_directory = getattr(d, "set_directory", None)
        if not callable(set_directory):
            return 0
        try:
            from .engine import directory as dr

            items: list = [ref.path for ref in d.documents()]
            scan_folder = getattr(d, "_scan_folder", None)
            if callable(scan_folder):
                for rel, (path, _size) in scan_folder(True).items():
                    if path.name.lower() == "users.json":
                        items.append(path)
            lang = self._dossier_language(d)
            directory = dr.build(items, lang=lang if lang in ("fr", "en") else "auto")
            set_directory(directory.to_dict() if directory else None)
            if directory:
                directory.seed(d, source="directory")
            return len(directory)
        except Exception as exc:  # noqa: BLE001 - the directory is an aid, never a blocker
            log.warning("RAGbase Shield: %s: directory not built (%s)", d.code, type(exc).__name__)
            return 0

    def _register_pass(self, d: Dossier) -> None:
        """v0.3 (synthetic leak fix, PLAN 5.1): a dossier in synthetic mode registers every value of every readable
        document in codes mode before a single fake is drawn, so the Synthesizer's collision rules see the whole
        dossier (a fake can never equal a real value that a later document holds). Rules-speed; never blocks."""
        m = self._masker(d, "codes")
        for ref in d.documents():
            try:
                raw = documents.read_text(ref.path)
            except (documents.DocumentError, OSError):
                continue
            if raw.needs_ocr or not raw.text or len(raw.text) > MAX_DOCUMENT_CHARS:
                continue
            try:
                m.mask(raw.text)
            except Exception as exc:  # noqa: BLE001 - the pass is a guard; the document is masked again below
                log.warning("RAGbase Shield: %s %s: registration pass failed (%s)", d.code, ref.id, type(exc).__name__)

    def _scan(self, d: Dossier) -> dict:
        n = unreadable = ocr = 0
        persons = self._build_directory(d)
        if self._dossier_replacement(d) == "synthetic":
            self._register_pass(d)
        for ref in d.documents():
            n += 1
            try:
                entry = self._doc(d, ref, fresh=True)
            except documents.DocumentError:
                unreadable += 1
                continue
            except OSError:
                unreadable += 1
                continue
            except ShieldError as exc:
                if exc.kind != "document_too_large":
                    raise
                unreadable += 1
                continue
            if entry.needs_ocr:
                ocr += 1
        return {"documents": n, "unreadable": unreadable, "needs_ocr": ocr, "directory": persons}

    @_guarded("scan_dossier")
    def scan_dossier(self, dossier_code: str) -> dict:
        """Re-read the folder and mask every document. {code, documents, entities, counts, unreadable, needs_ocr}."""
        with self._lock:
            d = self._dossier(dossier_code)
            summary = self._scan(d)
            d.journal("scan", documents=summary["documents"], entities=len(d.all()))
            summary.update(code=d.code, entities=len(d.all()), counts=_kind_counts(d))
            return summary

    @_guarded("remove_dossier")
    def remove_dossier(self, dossier_code: str) -> None:
        with self._lock:
            code = _dossier_code(dossier_code)
            self.registry.remove(code)
            self._drop_maskers(code)
            self._invalidate(code)

    @_guarded("entities")
    def entities(self, dossier_code: str) -> list[dict]:
        """[{code, kind, value, kept_clear, source, synthetic}] with REAL values: local display only.
        ``synthetic`` is the fake value the dossier gave in synthetic mode (None until one was needed)."""
        with self._lock:
            d = self._dossier(dossier_code)
            return [{"code": e.code, "kind": e.kind, "value": e.value, "kept_clear": d.is_kept_clear(e.norm),
                     "source": d.entity_source(e.code), "synthetic": d.synthetic(e.code)} for e in d.all()]

    @_guarded("register")
    def register(self, dossier_code: str, kind: str, value: str) -> dict:
        """The user adds a name or identifier. Returns {code, kind} (and value, for the local caller)."""
        with self._lock:
            d = self._dossier(dossier_code)
            kind = _kind_arg(kind)
            value = " ".join(str(value or "").split())
            if not value:
                raise ShieldError("Valeur vide (empty value).", "invalid_argument")
            ent = self._same_entity(d, kind, value)
            if ent is None:
                ent = d.register(kind, value)
                self._invalidate(d.code)
            d.journal("register", code=ent.code)
            return {"code": ent.code, "kind": ent.kind, "value": ent.value}

    def _same_entity(self, d: Dossier, kind: str, value: str) -> Optional[Entity]:
        """The existing entity with the same engine key ("Jean-Pierre DUPONT" = "Jean-Pierre Dupont",
        "ACME SAS" = "ACME"), so that registering a known name never creates a second code for it."""
        index = self._index(d)
        codes: set[str] = set()
        for key in {_safe_norm(kind, value), normalize(value)}:
            if key:
                codes |= index["key"].get((kind, key), set())
        return d.get_by_code(next(iter(codes))) if len(codes) == 1 else None

    @_guarded("keep_clear")
    def keep_clear(self, dossier_code: str, target: str, value: bool = True) -> dict:
        """Mark an entity code or a term "garder en clair" (``value=False`` masks it again)."""
        with self._lock:
            d = self._dossier(dossier_code)
            target = str(target or "").strip()
            if not target:
                raise ShieldError("Code ou terme vide (empty code or term).", "invalid_argument")
            if CODE_RE.fullmatch(target) and d.get_by_code(target) is None:
                raise ShieldError(f"{target} : code inconnu dans {d.code} (unknown code).", "invalid_argument")
            d.keep_clear(target, bool(value))
            self._invalidate(d.code)
            d.journal("keep_clear", code=target if CODE_RE.fullmatch(target) else None, value=bool(value))
            return {"ok": True}

    @_guarded("mask_text")
    def mask_text(self, text: str, dossier_code: Optional[str] = None, include_values: bool = False,
                  replacement: Optional[str] = None) -> dict:
        """Mask a text for the Desk, the CLI or the browser extension.

        {masked, found: [{code, kind[, value][, synthetic]}], counts: {KIND: mentions}, mode}. Without a dossier a
        temporary in-memory store is used. ``include_values`` adds the real value of each code (local page only).
        ``replacement`` (v0.2): "codes" or "synthetic" (realistic pseudonyms, kept in the dossier so that a
        later restore maps them back); None takes the dossier setting, else ``config.replacement()``.
        """
        with self._lock:
            text = _nfc(str(text or ""))
            if len(text) > MAX_MASK_CHARS:
                raise ShieldError("Texte trop long (text too long).", "invalid_argument")
            replacement = _replacement_arg(replacement)
            if dossier_code:
                d = self._dossier(dossier_code)
                m = self._masker(d, replacement)
                store: Any = d
            else:
                d = None
                store = MemoryStore(locale=config.locale())
                m = Masker(store, locale=config.locale(), replacement=replacement or config.replacement(),
                           language=config.language(), ner_model=config.ner_model(),
                           own_company_vendor=config.own_company_vendor())
            res = m.mask(text)
            # Always the canary of every dossier: without a dossier, a fresh masker cannot know the registered
            # names (a bare surname, a company without its legal form): they become [PERSONNE], [SOCIETE]...
            masked, canary = self._guard_report(res.text, d)
            found: list[dict] = []
            seen: set[str] = set()
            if res.mode == "synthetic":
                for code, rep in zip(res.codes, res.replacements):
                    if code in seen:
                        continue
                    ent = store.get_by_code(code)
                    if ent is None:
                        continue
                    seen.add(code)
                    item = {"code": code, "kind": ent.kind, "synthetic": rep}
                    if include_values:
                        item["value"] = ent.value
                    found.append(item)
            else:
                before = Counter(mm.group() for mm in UNMASK_RE.finditer(text))
                after = Counter(mm.group() for mm in UNMASK_RE.finditer(masked))
                for mm in UNMASK_RE.finditer(masked):
                    code = mm.group()
                    if code in seen or after[code] <= before.get(code, 0):
                        continue
                    ent = store.get_by_code(code)
                    if ent is None:
                        continue
                    seen.add(code)
                    item = {"code": code, "kind": ent.kind}
                    if include_values:
                        item["value"] = ent.value
                    found.append(item)
            counts = dict(Counter(s.kind for s in res.spans) + canary)
            if d is not None:
                if res.new_entities or res.mode == "synthetic":
                    self._invalidate(d.code)
                d.journal("mask", spans=len(res.spans), new_entities=len(res.new_entities),
                          synthetic=res.mode == "synthetic")
            return {"masked": masked, "found": found, "counts": counts, "canary": sum(canary.values()),
                    "mode": res.mode}

    @_guarded("set_dossier_setting")
    def set_dossier_setting(self, dossier_code: str, key: str, value: Optional[str]) -> dict:
        """Change a per-dossier setting (v0.2): ``replacement`` = "codes" | "synthetic", ``language`` = "auto" |
        "fr" | "en". ``None`` removes it. Returns the settings of the dossier. Local callers only (the CLI refuses
        in an AI agent's shell): a model never chooses how its own input is masked."""
        with self._lock:
            d = self._dossier(dossier_code)
            key = str(key or "").strip().lower()
            if key not in DOSSIER_SETTINGS:
                raise ShieldError("Réglage inconnu : language ou replacement (unknown setting).", "invalid_argument")
            if value is not None:
                value = str(value).strip().lower()
                if value not in DOSSIER_SETTINGS[key]:
                    raise ShieldError(f"Valeur refusée pour « {key} » : "
                                      + " | ".join(DOSSIER_SETTINGS[key]) + " (invalid setting value).",
                                      "invalid_argument")
            d.set_setting(key, value)
            self._drop_maskers(d.code)
            self._invalidate(d.code)
            d.journal("set_setting", synthetic=d.setting("replacement") == "synthetic")
            return dict(d.settings())

    @_guarded("restore_text")
    def restore_report(self, text: str, dossier_code: str) -> dict:
        """{text, unknown_codes, restored, placeholders, shield_ids}: codes of the dossier replaced by the real
        values (local only). ``placeholders`` lists the generic marks left ("[SOCIETE]"), ``shield_ids`` the
        DOC_n / DOSSIER_n / OUTPUT_n ids that got no local name (R1 corrections CL-31, CL-36)."""
        with self._lock:
            d = self._dossier(dossier_code)
            text = _nfc(str(text or ""))
            r = self._restore_out(self._masker(d), text, self._id_labels(d, text))
            d.journal("restore", restored=r["restored"], unknown_codes=len(r["unknown_codes"]),
                      placeholders=len(r["placeholders"]), shield_ids=len(r["shield_ids"]),
                      synthetic=r.get("restored_synthetic", 0), unmatched_synthetic=r.get("unmatched_synthetic", 0))
            return {"text": r["text"], "unknown_codes": r["unknown_codes"], "restored": r["restored"],
                    "placeholders": r["placeholders"], "shield_ids": r["shield_ids"],
                    "restored_synthetic": r.get("restored_synthetic", 0),
                    "unmatched_synthetic": r.get("unmatched_synthetic", 0)}

    def restore_text(self, text: str, dossier_code: str) -> str:
        """Restored text (local only)."""
        return self.restore_report(text, dossier_code)["text"]

    @_guarded("mask_file")
    def mask_file(self, path: os.PathLike | str, dossier_code: Optional[str] = None,
                  name: Optional[str] = None) -> dict:
        """Read a file and mask it: {name, masked_name, masked_text, needs_ocr, warnings} (Desk "Fichiers")."""
        with self._lock:
            p = Path(path)
            label = _nfc(name or p.name)
            raw = documents.read_text(p)
            stem, ext = os.path.splitext(label)
            ext = ext.lower() if re.fullmatch(r"\.[A-Za-z0-9]{1,8}", ext or "") else ""
            d = self._dossier(dossier_code) if dossier_code else None
            # The masked name becomes the download name of the masked copy: it must hold no registered value.
            masked_stem = self._clean_label(d, stem, "document")
            masked = "" if raw.needs_ocr else self.mask_text(raw.text, dossier_code)["masked"]
            return {"name": label, "masked_name": masked_stem + ext, "masked_text": masked,
                    "needs_ocr": bool(raw.needs_ocr), "warnings": list(raw.warnings)}

    @_guarded("journal")
    def journal(self, dossier_code: Optional[str] = None, limit: int = 500) -> list[dict]:
        with self._lock:
            code = _dossier_code(dossier_code) if dossier_code else None
            return self.registry.journal_entries(code, limit=limit)

    def folders(self) -> dict[str, Path]:
        """{DOSSIER_n: folder} (REAL paths, local use: hooks)."""
        return self.registry.folders()


def _label_tokens(label: str) -> list[tuple[int, int]]:
    """Letter and digit runs of a short label, split inside glued words: "MaelleKervadec2026" -> "Maelle",
    "Kervadec", "2026"; "Kervadec-c-Veltrane" -> "Kervadec", "c", "Veltrane"; "kervadec's" -> "kervadec", "s"."""
    out: list[tuple[int, int]] = []
    for m in re.finditer(r"[^\W_]+", label):
        a, b = m.start(), m.end()
        cut = a
        for i in range(a + 1, b):
            x, y = label[i - 1], label[i]
            split = (x.islower() and y.isupper()) or (x.isdigit() != y.isdigit())
            if not split and x.isupper() and y.isupper() and i + 1 < b:
                split = label[i + 1].islower()
            if split:
                out.append((cut, i))
                cut = i
        out.append((cut, b))
    return out


#: Dotted initials in a label: "R.T.", "R. T.", "J.-B. W", "J.B.W." (two to four letters).
_DOTTED_INITIALS_RE = re.compile(r"(?<![^\W\d_.])(?:[A-Z]\.[ \-]?){1,3}[A-Z]\.?(?![^\W\d_])")
_ACRONYM_SKIP = frozenset({"et", "and", "of", "the", "de", "du", "des", "d", "la", "le", "les", "l", "en", "sur",
                           "sous", "aux", "au", "a"})


def _org_acronyms(value: str) -> list[str]:
    """Folded acronyms of a registered company: first letters of its significant words, with and without the
    generic company words, 3 to 6 letters ("Brasserie Xavaron Quellec" -> "bxq", "xq" is too short).
    Uses ``names.org_acronyms`` when the engine has it (R1 interface), else this local rule."""
    from .engine import names as nm
    from .engine.normalize import fold_word

    helper = getattr(nm, "org_acronyms", None)
    if callable(helper):
        try:
            return sorted({fold_word(a).replace(".", "") for a in helper(value) if a})
        except Exception:  # noqa: BLE001 - fall back to the local rule
            pass
    words = re.findall(r"[^\W\d_]+", fold_word(nm.org_core(value)))
    sig = [w for w in words if w not in _ACRONYM_SKIP and w not in nm.LEGAL_FORMS and w not in nm.PARTICLES]
    if len(sig) < 2:
        return []
    out = set()
    for group in (sig, [w for w in sig if w not in nm.ORG_GENERIC]):
        if len(group) >= 2:
            out.add("".join(w[0] for w in group))
    return sorted(a for a in out if 3 <= len(a) <= 6 and not _weak_word(a))


def _person_initials(value: str) -> list[str]:
    """Folded initials groups of a registered person with first name and surname ("Jean-Basile Wardec" ->
    "jbw", "jw"). Uses ``names.person_initials`` when the engine has it (R1 interface), else this local rule."""
    from .engine import names as nm
    from .engine.normalize import fold_word

    helper = getattr(nm, "person_initials", None)
    if callable(helper):
        try:
            return sorted({re.sub(r"[^a-z]", "", fold_word(a)) for a in helper(value) if a} - {""})
        except Exception:  # noqa: BLE001 - fall back to the local rule
            pass
    firsts = nm.first_initials(value)
    sur = "".join(w[0] for w in nm.surname_key(value).split() if w)
    if not firsts or not sur:
        return []
    return sorted({firsts + sur, firsts[0] + sur})


def _label_glue(label: str, toks: list[tuple[int, int]], i: int) -> bool:
    """True when tokens ``i`` and ``i + 1`` are glued or joined by one or two separators ("-", "_", ".", " ")."""
    gap = label[toks[i][1]:toks[i + 1][0]]
    return len(gap) <= 2 and all(c in "-_. '’\u2010\u2011" for c in gap)


def _safe_norm(kind: str, value: str) -> str:
    try:
        return entity_norm(kind, value)
    except Exception:  # noqa: BLE001
        return ""


def _restore_for_output() -> Optional[Callable]:
    """``restore_utils.restore_for_output`` (owned by the RESTORE correction) when installed, else None."""
    try:
        from . import restore_utils  # type: ignore[attr-defined]
    except ImportError:
        return None
    helper = getattr(restore_utils, "restore_for_output", None)
    return helper if callable(helper) else None


@contextlib.contextmanager
def output_dossier(code: Optional[str]):
    """Inside this block, :meth:`Service.guard_output` treats the text as belonging to dossier ``code`` (the MCP
    server sets it around the last canary of a tool result): see :meth:`Service._guard_full`."""
    token = _OUTPUT_DOSSIER.set(str(code).strip().upper() if code else None)
    try:
        yield
    finally:
        _OUTPUT_DOSSIER.reset(token)


def _variant_keys(kind: str, value: str) -> list[tuple[str, ...]]:
    """Folded token sequences (OCR look-alikes merged) of the engine variants of a registered name."""
    from .engine import names as nm
    from .engine.normalize import fold_word

    try:
        variants = nm.person_variants(value) if kind == "PERSON" else nm.org_variants(value)
    except Exception:  # noqa: BLE001 - never fail the canary on one stored value
        return []
    return list(dict.fromkeys(tuple(fold_word(t, confusables=True) for t in v.tokens) for v in variants if v.tokens))


def _weak_word(folded: str) -> bool:
    """True for a folded word that is not a distinctive name word: in a word list (function words, legal terms,
    common words, first names, months, whitelist), a legal form, a title, a particle or a generic company word."""
    from .engine import names as nm

    stop, legal, common, _fn, afn, months, wl = nm._lists()
    parts = [p for p in re.split(r"[-'’]", folded) if p] or [folded]
    return all(p in stop or p in legal or p in common or p in afn or p in months or p in wl or p in nm.LEGAL_FORMS
               or p in nm.ORG_GENERIC or p in nm.TITLE_WORDS or p in nm.PARTICLES for p in parts)


def _strong_name_word(folded: str) -> bool:
    """A distinctive name word: 4 letters or more and in no word list ("brakevald", not "financiere")."""
    return len(folded) >= 4 and not _weak_word(folded)


_FORMS = {"sas", "sasu", "sarl", "eurl", "sci", "snc", "sa", "selarl", "selas", "scp", "gie", "ltd", "llc",
          "inc", "gmbh", "bv", "spa", "societe", "monsieur", "madame", "maitre", "mme", "me", "aarpi", "spfpl",
          "selafa", "selca", "scm"}


def _only_forms(rest: str) -> bool:
    words = re.findall(r"[^\W\d_]+", fold(rest).text)
    return all(w in _FORMS or len(w) < 4 for w in words)


def _kind_counts(d: Dossier) -> dict[str, int]:
    return dict(Counter(e.kind for e in d.all()))


_STOPWORDS = frozenset(
    "les des une aux par pour sur dans avec sans sous que qui quoi dont est sont ont etre avoir "
    "ses son sa leur leurs mais donc car cet cette ces nos vos notre votre the and for with from "
    "this that are was were not you your".split())


def _score_hits(found: list[tuple[int, str, int, int]]) -> list[tuple[int, int, int]]:
    """Score each match: its weight plus 2 per other query item found near it (same window)."""
    if not found:
        return []
    found = sorted(found, key=lambda h: h[2])
    starts = [h[2] for h in found]
    out = []
    for weight, item, ms, me in found:
        lo = bisect.bisect_left(starts, ms - 2 * SNIPPET_RADIUS)
        hi = bisect.bisect_right(starts, me + 2 * SNIPPET_RADIUS)
        near = {h[1] for h in found[lo:hi] if h[1] != item}
        out.append((weight + 2 * len(near), ms, me))
    return out


# ------------------------------------------------------------------------------------------ default instance

_DEFAULT: dict[str, Service] = {}
_DEFAULT_LOCK = threading.Lock()


def preload_ner() -> bool:
    """Load the NER model in a background thread so that the first document read does not wait 10 to 15 s
    (v0.2). Returns True when a load was started. Nothing happens when no model is installed or NER is off."""
    model = config.ner_model()
    if not _ner.ner_installed(model):
        return False
    threading.Thread(target=_ner.load_backend, args=(model,), name="shield-ner-preload", daemon=True).start()
    return True


def default() -> Service:
    """The service for the current ``config.home()`` (re-created when RAGBASE_SHIELD_HOME changes)."""
    home = str(config.home())
    with _DEFAULT_LOCK:
        svc = _DEFAULT.get(home)
        if svc is None:
            for old in _DEFAULT.values():
                try:
                    old.close()
                except Exception:  # noqa: BLE001
                    pass
            _DEFAULT.clear()
            svc = Service(home)
            _DEFAULT[home] = svc
        return svc


def reset() -> None:
    """Close the default service (tests, verify), and the registries the hooks keep open when they are loaded
    (an open file cannot be deleted on Windows)."""
    with _DEFAULT_LOCK:
        for svc in _DEFAULT.values():
            try:
                svc.close()
            except Exception:  # noqa: BLE001
                pass
        _DEFAULT.clear()
    hooks = sys.modules.get(__package__ + ".hooks")
    if hooks is not None:
        hooks.close_registries()


def list_dossiers(include_private: bool = False) -> list[dict]:
    return default().list_dossiers(include_private)


def list_documents(dossier_code: str) -> list[dict]:
    return default().list_documents(dossier_code)


def read_document(dossier_code: str, doc_id: str, start: int = 0, max_chars: int = DEFAULT_READ_CHARS) -> dict:
    return default().read_document(dossier_code, doc_id, start, max_chars)


def search(dossier_code: str, query: str, limit: int = DEFAULT_SEARCH_RESULTS) -> list[dict]:
    return default().search(dossier_code, query, limit)


def save_draft(dossier_code: str, title: str, content: str, fmt: str = "docx") -> dict:
    return default().save_draft(dossier_code, title, content, fmt)


def save_draft_report(dossier_code: str, title: str, content: str, fmt: str = "docx") -> dict:
    return default().save_draft_report(dossier_code, title, content, fmt)


def mask_text(text: str, dossier_code: Optional[str] = None, include_values: bool = False,
              replacement: Optional[str] = None) -> dict:
    return default().mask_text(text, dossier_code, include_values, replacement)


def set_dossier_setting(dossier_code: str, key: str, value: Optional[str]) -> dict:
    return default().set_dossier_setting(dossier_code, key, value)


def restore_text(text: str, dossier_code: str) -> str:
    return default().restore_text(text, dossier_code)


def restore_report(text: str, dossier_code: str) -> dict:
    return default().restore_report(text, dossier_code)


def scan_text(text: str) -> list[dict]:
    return default().scan_text(text)


def has_registered(text: str) -> bool:
    return default().has_registered(text)


def status() -> dict:
    return default().status()


def add_dossier(folder: os.PathLike | str, title: Optional[str] = None) -> dict:
    return default().add_dossier(folder, title)


def scan_dossier(dossier_code: str) -> dict:
    return default().scan_dossier(dossier_code)


def remove_dossier(dossier_code: str) -> None:
    default().remove_dossier(dossier_code)


def entities(dossier_code: str) -> list[dict]:
    return default().entities(dossier_code)


def register(dossier_code: str, kind: str, value: str) -> dict:
    return default().register(dossier_code, kind, value)


def keep_clear(dossier_code: str, target: str, value: bool = True) -> dict:
    return default().keep_clear(dossier_code, target, value)


def journal(dossier_code: Optional[str] = None, limit: int = 500) -> list[dict]:
    return default().journal(dossier_code, limit)


def mask_file(path: os.PathLike | str, dossier_code: Optional[str] = None, name: Optional[str] = None) -> dict:
    return default().mask_file(path, dossier_code, name)


def protect(text: str) -> tuple[str, list[str]]:
    return default().protect(text)
